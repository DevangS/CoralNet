==============
Django Userena
==============

Django userena's goal is to have a simple way to have full account management
for django application.

Please visit the homepage_ for documentation and preview of django-userena.

.. _homepage: http://django-userena.org
