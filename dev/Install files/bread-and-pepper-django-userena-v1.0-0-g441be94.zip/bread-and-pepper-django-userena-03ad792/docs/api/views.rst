.. _api-views:

Views
=====

.. automodule:: userena.views

signup
------

.. autofunction:: userena.views.signup

activate
--------

.. autofunction:: userena.views.activate

email_confirm
-------------

.. autofunction:: userena.views.email_confirm

direct_to_user_template
-----------------------

.. autofunction:: userena.views.direct_to_user_template

signin
------

.. autofunction:: userena.views.signin

email_change
------------

.. autofunction:: userena.views.email_change

password_change
---------------

.. autofunction:: userena.views.password_change

profile_edit
------------

.. autofunction:: userena.views.profile_edit

profile_detail
--------------

.. autofunction:: userena.views.profile_detail

profile_list
------------

.. autofunction:: userena.views.profile_list


