.. _api:

API Reference
=============

.. toctree::
   :maxdepth: 2
   
   backends
   decorators
   forms
   managers
   middleware
   models
   utils
   views
