.. _umessages-api:

API Reference
=============

.. toctree::
   :maxdepth: 2
   
   managers
   views
